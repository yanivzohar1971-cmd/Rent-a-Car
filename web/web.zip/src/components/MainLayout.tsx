import { Link, NavLink, Outlet } from 'react-router-dom';
import ScrollToTop from './ScrollToTop';
import NotificationBell from './NotificationBell';
import Footer from './Footer';
import { TenantFooterSurface, TenantHeaderSurface } from './tenant/TenantShellSurface';
import TenantLifecycleBanner from './tenant/TenantLifecycleBanner';
import { BRAND_NAME } from '../config/branding';
import './MainLayout.css';

export default function MainLayout() {
  return (
    <div className="main-layout">
      <ScrollToTop />
      <TenantHeaderSurface />
      <header className="header">
        <div className="header-content">
          <Link to="/" className="logo">
            <h1>{BRAND_NAME}</h1>
            <span className="logo-subtitle">לאתר חיפוש רכבים</span>
          </Link>
          <nav className="nav">
            <Link to="/sell" className="nav-cta-button">
              הוספת מודעה
            </Link>
            <NavLink 
              to="/" 
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            >
              עמוד הבית
            </NavLink>
            <NavLink 
              to="/cars" 
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            >
              רכבים למכירה
            </NavLink>
            <NavLink 
              to="/blog" 
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            >
              בלוג
            </NavLink>
            <NavLink 
              to="/account" 
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            >
              האזור האישי
            </NavLink>
            <NotificationBell />
          </nav>
        </div>
      </header>
      <main className="main-content">
        <TenantLifecycleBanner />
        <Outlet />
      </main>
      <TenantFooterSurface />
      <Footer />
    </div>
  );
}

