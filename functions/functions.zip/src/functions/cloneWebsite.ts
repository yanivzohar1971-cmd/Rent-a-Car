import * as admin from "firebase-admin";
import * as functions from "firebase-functions";

type CloneWebsiteRequest = {
  tenantId?: string;
  url?: string;
};

type CloneWebsiteResult = {
  ok: true;
  tenantId: string;
  sourceUrl: string;
  pages: Array<{ path: string; title?: string; html: string; fetchError?: string }>;
  html: string;
  documentHtml?: string;
  cssText?: string;
  styles?: string[];
  cssWarnings?: string[];
  updatedAt: string;
};

type ClonePageRecord = {
  path: string;
  url: string;
  sourceUrl: string;
  title: string;
  html: string;
  fetchError: string;
  status: "ok" | "error";
};

function sanitizeSourceUrlInput(raw: string): string {
  return raw.trim().replace(/^(source|מקור)\s*:\s*/i, "").trim();
}

function normalizeCharsetLabel(value: string | null | undefined): string | null {
  if (!value) return null;
  const c = value.trim().toLowerCase().replace(/["']/g, "");
  if (!c) return null;
  if (c === "utf8") return "utf-8";
  if (c === "cp1255" || c === "windows1255") return "windows-1255";
  if (c === "iso8859-8" || c === "iso88598" || c === "iso-8859-8-i") return "iso-8859-8";
  return c;
}

function detectCharsetFromBytes(bytes: Uint8Array, contentTypeHeader: string | null): string {
  const fromHeader = normalizeCharsetLabel(contentTypeHeader?.match(/charset\s*=\s*([^;]+)/i)?.[1]);
  if (fromHeader) return fromHeader;

  const headLen = Math.min(bytes.length, 32 * 1024);
  const headLatin = new TextDecoder("latin1").decode(bytes.slice(0, headLen));

  const charsetMeta = headLatin.match(/<meta\b[^>]*charset\s*=\s*["']?([^"'>\s;]+)/i);
  const fromMetaCharset = normalizeCharsetLabel(charsetMeta?.[1]);
  if (fromMetaCharset) return fromMetaCharset;

  const httpEquivMeta = headLatin.match(
    /<meta\b[^>]*http-equiv\s*=\s*["']?\s*content-type["']?[^>]*content\s*=\s*["']([^"']+)["']/i,
  );
  const fromHttpEquiv = normalizeCharsetLabel(httpEquivMeta?.[1]?.match(/charset\s*=\s*([^;"'\s]+)/i)?.[1]);
  if (fromHttpEquiv) return fromHttpEquiv;

  const contentMeta = headLatin.match(
    /<meta\b[^>]*content\s*=\s*["']([^"']*charset\s*=[^"']+)["'][^>]*http-equiv\s*=\s*["']?\s*content-type/i,
  );
  const fromContentMeta = normalizeCharsetLabel(contentMeta?.[1]?.match(/charset\s*=\s*([^;"'\s]+)/i)?.[1]);
  if (fromContentMeta) return fromContentMeta;

  return "utf-8";
}

function decodeHtmlFromResponseBytes(bytes: ArrayBuffer, contentTypeHeader: string | null): string {
  const u8 = new Uint8Array(bytes);
  const charset = detectCharsetFromBytes(u8, contentTypeHeader);
  try {
    return new TextDecoder(charset, { fatal: false }).decode(u8);
  } catch {
    return new TextDecoder("utf-8", { fatal: false }).decode(u8);
  }
}

function normalizeUrl(raw: string): URL {
  const trimmed = sanitizeSourceUrlInput(raw);
  if (!trimmed) {
    throw new functions.https.HttpsError("invalid-argument", "url is required");
  }
  const withProtocol = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  let parsed: URL;
  try {
    parsed = new URL(withProtocol);
  } catch {
    throw new functions.https.HttpsError("invalid-argument", "url is invalid");
  }
  if (!/^https?:$/i.test(parsed.protocol)) {
    throw new functions.https.HttpsError("invalid-argument", "Only http/https urls are supported");
  }
  parsed.hash = "";
  if (!parsed.pathname) parsed.pathname = "/";
  if (parsed.pathname !== "/") parsed.pathname = parsed.pathname.replace(/\/+$/, "");
  return parsed;
}

async function isAdmin(callerUid: string): Promise<boolean> {
  try {
    const user = await admin.auth().getUser(callerUid);
    if (user.customClaims?.admin === true) return true;
    const adminDoc = await admin.firestore().collection("config").doc("admins").get();
    const uids = ((adminDoc.data()?.uids as string[]) ?? []).filter(Boolean);
    return uids.includes(callerUid);
  } catch {
    return false;
  }
}

type SourceAssetType = "html";
type FetchSourceAssetOptions = {
  timeoutMs: number;
  assetType: SourceAssetType;
  referer?: string;
  acceptOverride?: string;
};

function buildSourceAssetHeaders(url: string, options: FetchSourceAssetOptions): Record<string, string> {
  const defaultAccept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
  const referer = options.referer?.trim() || `${new URL(url).origin}/`;
  return {
    "user-agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    accept: options.acceptOverride ?? defaultAccept,
    "accept-language": "he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7",
    referer,
    "cache-control": "no-cache",
    pragma: "no-cache",
  };
}

async function fetchSourceAsset(url: string, options: FetchSourceAssetOptions): Promise<Response> {
  const abort = new AbortController();
  const timeout = setTimeout(() => abort.abort(), options.timeoutMs);
  try {
    return await fetch(url, {
      method: "GET",
      headers: buildSourceAssetHeaders(url, options),
      redirect: "follow",
      signal: abort.signal,
    });
  } finally {
    clearTimeout(timeout);
  }
}

function extractBodyHtml(inputHtml: string): string {
  const bodyMatch = inputHtml.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
  if (bodyMatch?.[1]) return bodyMatch[1];
  return inputHtml;
}

function removeScripts(inputHtml: string): string {
  return inputHtml.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, "");
}

function removeEventHandlerAttributes(inputHtml: string): string {
  return inputHtml
    .replace(/\son\w+\s*=\s*"[^"]*"/gi, "")
    .replace(/\son\w+\s*=\s*'[^']*'/gi, "")
    .replace(/\son\w+\s*=\s*[^\s>]+/gi, "");
}

function removeJavascriptUrls(inputHtml: string): string {
  return inputHtml.replace(
    /\b(href|src)\s*=\s*(['"])\s*javascript:[\s\S]*?\2/gi,
    (_full, attr: string, quote: string) => `${attr}=${quote}#${quote}`,
  );
}

function sanitizeHtmlForStoredDocument(inputHtml: string): string {
  return removeJavascriptUrls(removeEventHandlerAttributes(removeScripts(inputHtml)));
}

function ensureUtf8Meta(headHtml: string): string {
  if (/<meta\b[^>]*charset\s*=|<meta\b[^>]*http-equiv\s*=\s*["']?\s*content-type/i.test(headHtml)) {
    return headHtml;
  }
  return `<meta charset="UTF-8">\n${headHtml}`;
}

function hasHebrewSignals(sourceUrl: URL, html: string): boolean {
  if (/\.co\.il$/i.test(sourceUrl.hostname)) return true;
  return /[\u0590-\u05FF]/.test(html);
}

function ensureRtlAttrs(htmlAttrsRaw: string, bodyAttrsRaw: string, sourceUrl: URL, rawHtml: string): { htmlAttrs: string; bodyAttrs: string } {
  let htmlAttrs = htmlAttrsRaw;
  let bodyAttrs = bodyAttrsRaw;
  const htmlHasDir = /\bdir\s*=/i.test(htmlAttrs);
  const bodyHasDir = /\bdir\s*=/i.test(bodyAttrs);
  const htmlHasLang = /\blang\s*=/i.test(htmlAttrs);
  if (!htmlHasDir && !bodyHasDir && hasHebrewSignals(sourceUrl, rawHtml)) {
    htmlAttrs += ' dir="rtl"';
  }
  if (!htmlHasLang && hasHebrewSignals(sourceUrl, rawHtml)) {
    htmlAttrs += ' lang="he"';
  }
  return { htmlAttrs, bodyAttrs };
}

function absolutizeAssetUrlsInHtml(inputHtml: string, baseUrl: string): string {
  const isAbsoluteOrSpecial = (value: string): boolean => {
    const v = value.trim().toLowerCase();
    return (
      v.startsWith("http://") ||
      v.startsWith("https://") ||
      v.startsWith("//") ||
      v.startsWith("data:") ||
      v.startsWith("blob:") ||
      v.startsWith("javascript:") ||
      v.startsWith("#")
    );
  };
  let out = inputHtml;
  const attrRe = /\b(src|href|poster)\s*=\s*(['"])(.*?)\2/gi;
  out = out.replace(attrRe, (full, attr, quote, raw) => {
    const v = String(raw ?? "").trim();
    if (!v || isAbsoluteOrSpecial(v)) return full;
    try {
      return `${attr}=${quote}${new URL(v, baseUrl).toString()}${quote}`;
    } catch {
      return full;
    }
  });
  const srcsetRe = /\bsrcset\s*=\s*(['"])(.*?)\1/gi;
  out = out.replace(srcsetRe, (full, quote, raw) => {
    const rewritten = String(raw ?? "")
      .split(",")
      .map((part) => {
        const trimmed = part.trim();
        if (!trimmed) return trimmed;
        const [urlPart, descriptor] = trimmed.split(/\s+/, 2);
        try {
          const abs = new URL(urlPart, baseUrl).toString();
          return descriptor ? `${abs} ${descriptor}` : abs;
        } catch {
          return trimmed;
        }
      })
      .join(", ");
    return `srcset=${quote}${rewritten}${quote}`;
  });
  return out;
}

function applyAssetManifestReplacements(inputHtml: string, manifest: Array<Record<string, unknown>>): string {
  const normalizeForCompare = (value: string): string => value.trim().replace(/^['"]|['"]$/g, "");
  const isAbsoluteOrSpecial = (value: string): boolean => {
    const v = normalizeForCompare(value).toLowerCase();
    return (
      v.startsWith("http://") ||
      v.startsWith("https://") ||
      v.startsWith("//") ||
      v.startsWith("data:") ||
      v.startsWith("blob:") ||
      v.startsWith("javascript:") ||
      v.startsWith("#")
    );
  };

  const replacementMap = new Map<string, string>();
  for (const item of manifest) {
    const originalUrlRaw = typeof item.originalUrl === "string" ? item.originalUrl : "";
    const storageUrl = typeof item.storageUrl === "string" ? item.storageUrl : "";
    if (!originalUrlRaw || !storageUrl) continue;
    const originalUrl = normalizeForCompare(originalUrlRaw);
    replacementMap.set(originalUrl, storageUrl);
    if (!originalUrl.startsWith("/")) replacementMap.set(`/${originalUrl}`, storageUrl);
  }

  const replaceOne = (raw: string): string => {
    const candidate = normalizeForCompare(raw);
    const direct = replacementMap.get(candidate);
    if (direct) return direct;
    return raw;
  };

  let out = inputHtml;
  const attrRe = /\b(src|href|poster)\s*=\s*(['"])(.*?)\2/gi;
  out = out.replace(attrRe, (full, attr, quote, raw) => {
    const replaced = replaceOne(String(raw ?? ""));
    if (!replaced || replaced === raw) return full;
    if (isAbsoluteOrSpecial(replaced)) {
      return `${attr}=${quote}${replaced}${quote}`;
    }
    return `${attr}=${quote}${replaced}${quote}`;
  });

  const srcsetRe = /\bsrcset\s*=\s*(['"])(.*?)\1/gi;
  out = out.replace(srcsetRe, (full, quote, raw) => {
    const rewritten = String(raw ?? "")
      .split(",")
      .map((part) => {
        const trimmed = part.trim();
        if (!trimmed) return trimmed;
        const [urlPart, descriptor] = trimmed.split(/\s+/, 2);
        const replaced = replaceOne(urlPart);
        const finalUrl = replaced || urlPart;
        return descriptor ? `${finalUrl} ${descriptor}` : finalUrl;
      })
      .join(", ");
    return `srcset=${quote}${rewritten}${quote}`;
  });

  // Safety-net: if malformed "/https://..." was produced by legacy data, normalize it.
  out = out.replace(/=(['"])\/(https?:\/\/[^'"]+)\1/gi, `="$2"`);
  return out;
}

function stripUndefinedDeep(value: unknown): unknown {
  if (value === undefined) return undefined;
  if (Array.isArray(value)) {
    return value
      .map((item) => stripUndefinedDeep(item))
      .filter((item) => item !== undefined);
  }
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) {
      const cleaned = stripUndefinedDeep(v);
      if (cleaned !== undefined) out[k] = cleaned;
    }
    return out;
  }
  return value;
}

function buildDocumentHtml(
  sourceHtmlRaw: string,
  rewrittenBodyHtml: string,
  cssText: string,
  sourceUrl: URL,
): string {
  const sanitizedSource = sanitizeHtmlForStoredDocument(sourceHtmlRaw);
  const doctypeMatch = sanitizedSource.match(/^\s*(<!doctype[^>]*>)/i);
  const doctype = doctypeMatch?.[1] ?? "<!doctype html>";
  const htmlAttrsRaw = sanitizedSource.match(/<html\b([^>]*)>/i)?.[1] ?? "";
  const bodyAttrsRaw = sanitizedSource.match(/<body\b([^>]*)>/i)?.[1] ?? "";
  const { htmlAttrs, bodyAttrs } = ensureRtlAttrs(htmlAttrsRaw, bodyAttrsRaw, sourceUrl, sourceHtmlRaw);
  let headInner = sanitizedSource.match(/<head\b[^>]*>([\s\S]*?)<\/head>/i)?.[1] ?? "";
  headInner = removeScripts(headInner);
  headInner = headInner.replace(/<(iframe|object|embed)\b[\s\S]*?<\/\1>/gi, "");
  headInner = ensureUtf8Meta(headInner);

  const safeCss = (cssText ?? "").replace(/<\/style/gi, "<\\/style");
  if (safeCss.trim()) {
    headInner += `\n<style data-clone-styles="true">${safeCss}</style>`;
  }

  const safeBody = sanitizeHtmlForStoredDocument(rewrittenBodyHtml);
  return `${doctype}
<html${htmlAttrs}>
<head>
${headInner}
</head>
<body${bodyAttrs}>${safeBody}</body>
</html>`;
}

function toClonePathname(pathname: string): string {
  const clean = pathname.trim();
  if (!clean || clean === "/") return "/";
  return clean.startsWith("/") ? clean : `/${clean}`;
}

function rewriteInternalLinks(
  bodyHtml: string,
  tenantId: string,
  sourceUrl: URL,
): { html: string; discoveredPaths: string[] } {
  const sourceHost = sourceUrl.hostname.toLowerCase();
  const cloneBase = `/tenant/${encodeURIComponent(tenantId)}/clone`;
  const discoveredPaths = new Set<string>(["/"]);

  const rewritten = bodyHtml.replace(/<a\b([^>]*?)\bhref\s*=\s*(['"])(.*?)\2([^>]*)>/gi, (full, before, quote, hrefRaw, after) => {
    const href = String(hrefRaw ?? "").trim();
    if (!href) return full;

    const lowerHref = href.toLowerCase();
    if (
      lowerHref.startsWith("#") ||
      lowerHref.startsWith("javascript:") ||
      lowerHref.startsWith("mailto:") ||
      lowerHref.startsWith("tel:")
    ) {
      return full;
    }

    let isInternal = false;
    let resolvedPath = "";

    if (href.startsWith("/") || href.startsWith("./")) {
      try {
        const resolved = new URL(href, sourceUrl);
        resolvedPath = toClonePathname(resolved.pathname);
        isInternal = true;
      } catch {
        isInternal = false;
      }
    } else if (/^https?:\/\//i.test(href)) {
      try {
        const target = new URL(href);
        if (target.hostname.toLowerCase() === sourceHost) {
          resolvedPath = toClonePathname(target.pathname);
          isInternal = true;
        }
      } catch {
        isInternal = false;
      }
    }

    if (!isInternal) return full;
    discoveredPaths.add(resolvedPath || "/");

    const rewrittenHref = resolvedPath === "/" ? cloneBase : `${cloneBase}${resolvedPath}`;
    const attrs = `${before}href=${quote}${rewrittenHref}${quote}${after}`;
    const originalAttr = ` data-original-href=${quote}${href}${quote}`;
    const cloneAttr = ` data-clone-link=${quote}true${quote}`;
    return `<a${attrs}${originalAttr}${cloneAttr}>`;
  });
  return { html: rewritten, discoveredPaths: [...discoveredPaths] };
}

function extractTitle(inputHtml: string): string | undefined {
  const m = inputHtml.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const t = (m?.[1] ?? "").replace(/\s+/g, " ").trim();
  return t || undefined;
}

function extractStylesFromHtml(inputHtml: string): { stylesheetHrefs: string[] } {
  const stylesheetHrefs = new Set<string>();

  const linkRe = /<link\b([^>]*?)>/gi;
  let m: RegExpExecArray | null;
  while ((m = linkRe.exec(inputHtml)) !== null) {
    const attrs = m[1] ?? "";
    const rel = attrs.match(/\brel\s*=\s*(['"])(.*?)\1/i)?.[2]?.toLowerCase() ?? "";
    if (!rel.includes("stylesheet")) continue;
    const href = attrs.match(/\bhref\s*=\s*(['"])(.*?)\1/i)?.[2]?.trim() ?? "";
    if (href) stylesheetHrefs.add(href);
  }

  return { stylesheetHrefs: [...stylesheetHrefs] };
}

async function fetchHtmlWithTimeout(url: string, timeoutMs: number): Promise<Response> {
  return fetchSourceAsset(url, {
    timeoutMs,
    assetType: "html",
    referer: `${new URL(url).origin}/`,
  });
}

export async function cloneWebsiteHandler(data: unknown, context: functions.https.CallableContext): Promise<CloneWebsiteResult> {
  if (!context.auth?.uid) {
    throw new functions.https.HttpsError("unauthenticated", "User must be authenticated");
  }

  const callerIsAdmin = await isAdmin(context.auth.uid);
  if (!callerIsAdmin) {
    throw new functions.https.HttpsError("permission-denied", "Admin privileges required");
  }

  const body = (typeof data === "object" && data !== null ? data : {}) as CloneWebsiteRequest;
  const tenantId = (body.tenantId ?? "").trim();
  const urlRaw = (body.url ?? "").trim();
  if (!tenantId) {
    throw new functions.https.HttpsError("invalid-argument", "tenantId is required");
  }

  let stage = "normalize_url";
  let normalizedUrl = "";
  let currentUrl = "";
  let httpStatus: number | null = null;
  let contentType: string | null = null;
  try {
    const sourceUrl = normalizeUrl(urlRaw);
    normalizedUrl = sourceUrl.toString();
    currentUrl = normalizedUrl;
    stage = "load_existing_clone";
    const existingCloneSnap = await admin.firestore().collection("tenantSiteClones").doc(tenantId).get();
    const existingCloneData = (existingCloneSnap.data() ?? {}) as Record<string, unknown>;
    const existingAssetManifest = Array.isArray(existingCloneData.assetManifest)
      ? (existingCloneData.assetManifest as Array<Record<string, unknown>>)
      : [];
    stage = "fetch_root_html";
    const response = await fetchHtmlWithTimeout(sourceUrl.toString(), 10_000);
    httpStatus = response.status;
    contentType = response.headers.get("content-type");
    if (!response.ok) {
      throw new Error(`root_fetch_http_${response.status}`);
    }

    stage = "decode_root_html";
    const rootHtmlRaw = decodeHtmlFromResponseBytes(await response.arrayBuffer(), response.headers.get("content-type"));
  const rootBodyHtml = extractBodyHtml(rootHtmlRaw);
  const rootNoScriptsHtml = removeScripts(absolutizeAssetUrlsInHtml(rootBodyHtml, sourceUrl.toString()));
  const rootRewritten = rewriteInternalLinks(rootNoScriptsHtml, tenantId, sourceUrl);
  const rootTitle = extractTitle(rootHtmlRaw);
  const rootStyles = extractStylesFromHtml(rootHtmlRaw);

  const MAX_PAGES = 10;
  const PAGE_TIMEOUT_MS = 8_000;
  const queue: string[] = [...new Set(rootRewritten.discoveredPaths.map((p) => toClonePathname(p)))];
  if (!queue.includes("/")) queue.unshift("/");
  const visited = new Set<string>();
  const pages: ClonePageRecord[] = [];
  const collectedStylesheets = new Set<string>();
  const cssWarnings: string[] = [];

  for (const href of rootStyles.stylesheetHrefs) {
    try {
      collectedStylesheets.add(new URL(href, sourceUrl).toString());
    } catch {
      cssWarnings.push(`stylesheet_invalid:${href}`);
    }
  }

  stage = "crawl_pages";
  while (queue.length > 0 && pages.length < MAX_PAGES) {
    const path = toClonePathname(queue.shift() ?? "/");
    if (visited.has(path)) continue;
    visited.add(path);

    const pageUrl = new URL(path, sourceUrl).toString();
    currentUrl = pageUrl;
    try {
      const pageRes = await fetchHtmlWithTimeout(pageUrl, PAGE_TIMEOUT_MS);
      httpStatus = pageRes.status;
      contentType = pageRes.headers.get("content-type");
      if (!pageRes.ok) {
        pages.push({
          path,
          url: pageUrl,
          sourceUrl: pageUrl,
          title: path === "/" ? rootTitle ?? "" : "",
          html: rootRewritten.html,
          fetchError: `HTTP ${pageRes.status}`,
          status: "error",
        });
        continue;
      }
      const pageHtmlRaw = decodeHtmlFromResponseBytes(await pageRes.arrayBuffer(), pageRes.headers.get("content-type"));
      const pageBody = removeScripts(absolutizeAssetUrlsInHtml(extractBodyHtml(pageHtmlRaw), pageUrl));
      const pageRewritten = rewriteInternalLinks(pageBody, tenantId, sourceUrl);
      const pageStyles = extractStylesFromHtml(pageHtmlRaw);
      for (const href of pageStyles.stylesheetHrefs) {
        try {
          collectedStylesheets.add(new URL(href, pageUrl).toString());
        } catch {
          cssWarnings.push(`stylesheet_invalid:${href}`);
        }
      }
      pages.push({
        path,
        url: pageUrl,
        sourceUrl: pageUrl,
        title: extractTitle(pageHtmlRaw) ?? "",
        html: pageRewritten.html,
        fetchError: "",
        status: "ok",
      });
      for (const discovered of pageRewritten.discoveredPaths) {
        const normalized = toClonePathname(discovered);
        if (!visited.has(normalized) && !queue.includes(normalized) && pages.length + queue.length < MAX_PAGES * 2) {
          queue.push(normalized);
        }
      }
    } catch (error) {
      const msg = error instanceof Error ? error.message : "Fetch failed";
      pages.push({
        path,
        url: pageUrl,
        sourceUrl: pageUrl,
        title: path === "/" ? rootTitle ?? "" : "",
        html: rootRewritten.html,
        fetchError: msg.slice(0, 180) || "fetch_failed",
        status: "error",
      });
    }
  }

  pages.sort((a, b) => a.path.localeCompare(b.path));
  const homePage = pages.find((p) => p.path === "/");
  const fallbackHtml = homePage?.html ?? rootRewritten.html;
  const stylesheetUrls = [...collectedStylesheets].sort();
  const cssText = "";
  const htmlWithManifest = applyAssetManifestReplacements(fallbackHtml, existingAssetManifest);
  const pagesWithManifest: ClonePageRecord[] = pages.map((p) => ({
    path: p.path || "/",
    url: p.url || "",
    sourceUrl: p.sourceUrl || "",
    title: p.title || "",
    html: applyAssetManifestReplacements(p.html || "", existingAssetManifest),
    fetchError: p.fetchError || "",
    status: p.status ?? "ok",
  }));
  const documentHtml = buildDocumentHtml(rootHtmlRaw, htmlWithManifest, cssText, sourceUrl);

  stage = "persist_clone";
  const now = admin.firestore.FieldValue.serverTimestamp();
  const docRef = admin.firestore().collection("tenantSiteClones").doc(tenantId);
  const clonePayloadRaw = {
    tenantId,
    sourceUrl: sourceUrl.toString(),
    normalizedUrl: normalizedUrl,
    pages: pagesWithManifest,
    html: htmlWithManifest,
    documentHtml,
    cssText,
    styles: stylesheetUrls,
    cssWarnings: cssWarnings.filter((w) => !/^css_http_406/i.test(w)),
    createdByUid: context.auth.uid,
    updatedAt: now,
  };
  const clonePayload = stripUndefinedDeep(clonePayloadRaw) as Record<string, unknown>;
  await docRef.set(
    clonePayload,
    { merge: true },
  );

  stage = "return_result";
  return {
    ok: true,
    tenantId,
    sourceUrl: normalizedUrl,
    pages: pagesWithManifest,
    html: htmlWithManifest,
    documentHtml,
    cssText,
    styles: stylesheetUrls,
    cssWarnings: cssWarnings.filter((w) => !/^css_http_406/i.test(w)),
    updatedAt: new Date().toISOString(),
  };
  } catch (error) {
    const message = error instanceof Error ? error.message : "cloneWebsite failed";
    throw new functions.https.HttpsError("internal", "cloneWebsite failed", {
      stage,
      sourceUrl: urlRaw || null,
      normalizedUrl: normalizedUrl || null,
      currentUrl: currentUrl || null,
      httpStatus,
      contentType,
      message: message.slice(0, 500),
    });
  }
}
